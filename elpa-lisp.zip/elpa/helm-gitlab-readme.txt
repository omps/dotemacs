Provides a Helm interface to Gitlab
