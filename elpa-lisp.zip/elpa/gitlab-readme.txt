Provides a Gitlab client for Emacs.

Installation:

Available as a package in melpa.milkbox.net.

(add-to-list 'package-archives
             '("melpa" . "http://melpa.milkbox.net/packages/") t)

M-x package-install gitlab
